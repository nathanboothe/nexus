# Home IoT Dashboard

A Node/Express backend that integrates **Home Assistant** (REST) plus **direct
devices** (MQTT and HTTP), and serves a **Vite-built React** frontend that polls
every few seconds. Designed to run as a **Windows Service** on Windows Server
2025, reachable from anywhere over **Tailscale** (no public exposure).

```
server/   Node/Express + integration adapters
client/   React + Vite frontend
```

---

## Local layout

- `server/server.js` — entry point; merges adapters, exposes `/api/devices`,
  serves the built client.
- `server/adapters/` — one file per source: `homeAssistant.js`, `httpDevices.js`,
  `mqttDevices.js`. Add new sources by adding an adapter with a `poll()` method.
- `server/config.js` — your real settings (copy from `config.example.js`).
  **Gitignored — holds your HA token.**
- `client/src/App.jsx` — polls `/api/devices`, renders cards grouped by source.

---

## Deploying on Windows Server 2025

> Assumes Node.js 24 LTS is installed (`winget install --id OpenJS.NodeJS.LTS -e`)
> and you're connected via RDP or PowerShell Remoting.

### 1. Get the code onto the server

Put the project at e.g. `C:\apps\iot-dashboard`. Then:

```powershell
cd C:\apps\iot-dashboard\server
copy config.example.js config.js   # then edit config.js with your real values
npm install

cd ..\client
npm install
npm run build                       # produces client\dist (served by the backend)
```

### 2. Test it runs by hand first

```powershell
cd C:\apps\iot-dashboard\server
node server.js
# Browse to http://localhost:8080 on the server itself. Confirm cards appear.
# Ctrl+C to stop once it works.
```

Don't wrap it as a service until it runs cleanly by hand — debugging a service
is harder than debugging a console process.

### 3. Install Tailscale (remote access without exposing anything)

Install Tailscale on the server (`winget install --id tailscale.tailscale -e`)
and on each device you'll view the dashboard from (phone, laptop). Sign each
into the **same** tailnet. The server gets a stable `100.x.y.z` Tailscale IP —
that's how you reach the dashboard from anywhere, as if on the LAN. No Firewalla
ports are opened. Because only enrolled devices can route to it, the dashboard
needs no login of its own to start.

### 4. Wrap as a Windows Service with NSSM

```powershell
winget install --id NSSM.NSSM -e        # or download from nssm.cc

nssm install IoTDashboard "C:\Program Files\nodejs\node.exe" "C:\apps\iot-dashboard\server\server.js"
nssm set IoTDashboard AppDirectory "C:\apps\iot-dashboard\server"
nssm set IoTDashboard Start SERVICE_AUTO_START
nssm set IoTDashboard AppStdout "C:\apps\iot-dashboard\logs\out.log"
nssm set IoTDashboard AppStderr "C:\apps\iot-dashboard\logs\err.log"
nssm start IoTDashboard
```

Manage it like any service: `nssm restart IoTDashboard`, `nssm stop IoTDashboard`,
or via `services.msc`. Logs land in `C:\apps\iot-dashboard\logs`.

### 5. After any code or config change

```powershell
# If you changed the client, rebuild it:
cd C:\apps\iot-dashboard\client; npm run build
# Then restart the service so the backend picks everything up:
nssm restart IoTDashboard
```

---

## Notes from prior setup experience

- **Fixed IP:** give the VM a DHCP reservation on the Firewalla (keyed to its
  MAC, `Get-NetAdapter | fl Name,MacAddress`), not a static IP inside Windows.
- **If remote access dies:** Tailscale runs its own overlay and shouldn't be
  affected by the wireless-bridge/MAC issues seen previously. If RDP/WinRM both
  fail while the server is up, diagnose from the Hyper-V console.
- **HA 401 errors:** almost always a bad or expired long-lived access token in
  `config.js`.
