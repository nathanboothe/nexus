// layout.js
// Defines the dashboard's navigation structure. Edit this to add/rearrange
// screens. Each panel lists the HA entity_ids it should display.
//
// status: "live"      -> populated with real data now (Stage B)
//         "planned"   -> shell exists, fills in later (Stage C control / Stage D cameras)
//
// kind:   "sensor"    -> read-only value cards (works today)
//         "control"   -> interactive lights/media (Stage C, needs service calls + auth)
//         "camera"    -> live video feeds (Stage D, needs stream proxying)

export const PANELS = [
  // ---------- GLOBAL PANELS ----------
  {
    id: "climate",
    title: "Climate & Air",
    icon: "thermo",
    group: "global",
    status: "live",
    kind: "climate",
    // The thermostat (verified: climate.hallway).
    thermostat: "climate.hallway",
    // Air monitors grouped by room. Each shows temp + humidity + air quality.
    // Rec Room humidity/airquality IDs confirmed from states dump; others
    // follow the same naming pattern (VERIFY if any room's cards are empty).
    airMonitors: [
      { room: "Rec Room", temp: "sensor.rec_room_air_monitor_temperature", humidity: "sensor.rec_room_air_monitor_humidity", aqi: "sensor.rec_room_air_monitor_airquality" },
      { room: "Loft", temp: "sensor.loft_air_monitor_temperature", humidity: "sensor.loft_air_monitor_humidity", aqi: "sensor.loft_air_monitor_airquality" },
      { room: "Sam's", temp: "sensor.sam_s_air_monitor_temperature", humidity: "sensor.sam_s_air_monitor_humidity", aqi: "sensor.sam_s_air_monitor_airquality" },
      { room: "Tyler's", temp: "sensor.tyler_s_air_monitor_temperature", humidity: "sensor.tyler_s_air_monitor_humidity", aqi: "sensor.tyler_s_air_monitor_airquality" },
      { room: "Lucas's", temp: "sensor.lucqs_room_air_monitor_temperature", humidity: "sensor.lucqs_room_air_monitor_humidity", aqi: "sensor.lucqs_room_air_monitor_airquality" },
    ],
    // Hallway temp/humidity are the thermostat's own readings — shown
    // inside the thermostat card, not as a separate section.
    thermostatSensors: {
      humidity: "sensor.hallway_humidity",
      temperature: "sensor.hallway_temperature",
    },
    entities: [],
  },
  {
    id: "network",
    title: "Network",
    icon: "globe",
    group: "global",
    status: "live",
    kind: "sensor",
    entities: [
      "binary_sensor.firewalla_wan_status",
      "sensor.firewalla_external_ip",
      "sensor.firewalla_download_speed",
      "sensor.firewalla_upload_speed",
    ],
  },
  {
    id: "cameras",
    title: "Cameras",
    icon: "camera",
    group: "global",
    status: "live",
    kind: "cameras",
    // Cameras grouped by location. (event.*_motion entities are motion
    // events, not feeds, so they're not listed here.)
    cameraGroups: [
      {
        name: "Outdoor",
        cameras: [
          { id: "camera.entry_way_doorbell", name: "Entry Way Doorbell" },
          { id: "camera.driveway_view", name: "Driveway View" },
          { id: "camera.patio_view", name: "Patio View" },
          { id: "camera.deck_view", name: "Deck View" },
          { id: "camera.rec_room_door_view", name: "Rec Room Door" },
          { id: "camera.cottage_view", name: "Cottage View" },
          { id: "camera.house_right_side_view", name: "House Right Side" },
        ],
      },
      {
        name: "Indoor",
        cameras: [
          { id: "camera.rec_room_indoor_camera", name: "Rec Room Indoor" },
          { id: "camera.living_room_camera", name: "Living Room" },
          { id: "camera.loft_camera", name: "Loft" },
        ],
      },
    ],
    entities: [],
  },

  {
    id: "audio",
    title: "Audio",
    icon: "speaker",
    group: "global",
    status: "live",
    kind: "control",
    media: [
      "media_player.kitchen_speaker",
      "media_player.living_room_speaker",
      "media_player.loft_speaker",
      "media_player.lucas_bedroom_speaker",
      "media_player.master_bedroom_speaker",
      "media_player.sam_bedroom_speaker",
    ],
    entities: [],
  },

  {
    id: "planner",
    title: "Tasks",
    icon: "tasks",
    group: "global",
    status: "live",
    kind: "planner",
    entities: [],
  },

  // ---------- ROOMS ----------
  {
    id: "rec_room",
    title: "Rec Room",
    icon: "sofa",
    group: "room",
    status: "live",
    kind: "control",
    // Grouped by control type so the panel can render the right widget.
    lights: {
      groups: [
        "light.rec_room_lights",
        "light.rec_room_floor_lamps",
        "light.rec_room_default_lighting",
        "light.back_rec_room_fan",
        "light.front_rec_room_fan",
        "light.fridge_lights",
      ],
      bulbs: [
        "light.fireplace_light",
        "light.fridge_1",
        "light.fridge_2",
        "light.fridge_3",
        "light.right_floor_lamp",
        "light.left_floor_lamp",
        "light.h6076_173d",
        "light.back_fan_bulb_1",
        "light.back_fan_bulb_2",
        "light.back_fan_bulb_3",
        "light.back_fan_bulb_4",
        "light.front_fan_bulb_1",
        "light.front_fan_bulb_2",
        "light.front_fan_bulb_3",
        "light.front_fan_bulb_4",
      ],
    },
    purifier: {
      power: "switch.rec_room_air_purifier_power_switch",
      mode: "select.rec_room_air_purifier_mode",
    },

    // ---- Nathan's Desk ----
    // Samsung M8 monitor. Power + volume via the media_player entity; D-pad
    // navigation via the remote entity (Samsung KEY_* codes through
    // remote.send_command). Key codes are standard Samsung; confirm on test.
    deskSection: {
      title: "Nathan's Desk",
      media: "media_player.smart_monitor_m8",
      remote: "remote.smart_monitor_m8",
      nav: {
        up: { label: "Up", command: "KEY_UP", icon: "up" },
        down: { label: "Down", command: "KEY_DOWN", icon: "down" },
        left: { label: "Left", command: "KEY_LEFT", icon: "left" },
        right: { label: "Right", command: "KEY_RIGHT", icon: "right" },
        ok: { label: "OK", command: "KEY_ENTER", icon: "ok" },
      },
      // Volume via the remote too (more reliable than media volume on some
      // Samsung models); falls back fine if media volume also works.
      volume: [
        { label: "Vol −", command: "KEY_VOLDOWN" },
        { label: "Vol +", command: "KEY_VOLUP" },
      ],
    },

    // ---- Activities (home theater control via Broadlink + HA scripts) ----
    // All values verified against the user's "Family Mobile" HA dashboard YAML.
    activities: {
      // Default remote for commands that don't specify their own.
      remoteEntity: "remote.base_station",

      // ONE parameterized script launches any streaming app on the Google TV.
      streamingScript: "script.switch_to_google_tv",
      // `icon` maps to BrandIcon glyphs where available; others show text only.
      streaming: [
        { label: "Netflix", activity: "com.netflix.ninja", icon: "netflix" },
        { label: "YouTube", activity: "com.google.android.youtube.tv", icon: "youtube" },
        { label: "Prime Video", activity: "com.amazon.amazonvideo.livingroom", icon: "prime" },
        { label: "Hulu", activity: "com.hulu.livingroomplus", icon: "hulu" },
        { label: "Disney+", activity: "com.disney.disneyplus", icon: "disney" },
        { label: "Peacock", activity: "com.peacocktv.peacockandroid", icon: "peacock" },
        { label: "HBO Max", activity: "com.wbd.stream", icon: "hbomax" },
        { label: "Apple TV", activity: "com.apple.atve.androidtv.appletv", icon: "appletv" },
        { label: "Vudu", activity: "air.com.vudu.air.DownloaderTablet", icon: "vudu" },
        // Action TBD — placeholder activity to be filled in later.
        { label: "Paramount+", activity: "PARAMOUNT_TBD", icon: "paramount" },
      ],

      // Quick Play: full macro commands on base_station (no `device` field).
      quickPlay: [
        { label: "PS5", command: "Play PS5", icon: "ps5" },
        { label: "Xbox", command: "Play Xbox", icon: "xbox" },
        { label: "Switch 2", command: "Play Switch 2", icon: "nintendoswitch" },
        // Atari icon added for future use; action TBD.
        { label: "Atari", command: "ATARI_TBD", icon: "atari" },
      ],

      // Navigation D-pad: these go to remote.rec_room_google_tv (not base).
      nav: {
        remote: "remote.rec_room_google_tv",
        // grid order matches the on-screen 3x3 layout
        home: { label: "Home", command: "HOME", icon: "home" },
        up: { label: "Up", command: "DPAD_UP", icon: "up" },
        left: { label: "Left", command: "DPAD_LEFT", icon: "left" },
        ok: { label: "OK", command: "ENTER", icon: "ok" },
        right: { label: "Right", command: "DPAD_RIGHT", icon: "right" },
        back: { label: "Back", command: "BACK", icon: "back" },
        down: { label: "Down", command: "DPAD_DOWN", icon: "down" },
        menu: { label: "Menu", command: "MENU", icon: "menu" },
        // TV Mute removed per request.
      },

      // Denon volume -> base_station. Vol−/Vol+ side by side, Mute below.
      volume: [
        { label: "Vol −", device: "denon_receiver", command: "volume_down" },
        { label: "Vol +", device: "denon_receiver", command: "volume_up" },
        { label: "Mute", device: "denon_receiver", command: "mute" },
      ],

      // Individual power toggles -> base_station (verified).
      power: [
        { label: "TV", device: "tv", command: "power" },
        { label: "Denon", device: "denon_receiver", command: "power" },
      ],

      // Master off -> HA script.
      allOff: { label: "Turn Everything Off", script: "script.entertainment_off" },
    },

    // Flat list of everything this panel needs fetched from HA.
    entities: [],
  },
  { id: "kitchen", title: "Kitchen", icon: "kitchen", group: "room", status: "live", kind: "control", media: ["media_player.kitchen_speaker"], entities: [] },
  { id: "living_room", title: "Living Room", icon: "sofa", group: "room", status: "live", kind: "control", media: ["media_player.living_room_speaker"], entities: [] },
  { id: "loft", title: "Loft", icon: "stairs", group: "room", status: "live", kind: "control", media: ["media_player.loft_speaker"], entities: [] },
  { id: "master", title: "Master Bedroom", icon: "bed", group: "room", status: "live", kind: "control", media: ["media_player.master_bedroom_speaker"], entities: [] },
  { id: "sam", title: "Sam's Room", icon: "bed", group: "room", status: "live", kind: "control", media: ["media_player.sam_bedroom_speaker"], switches: [{ power: "switch.star_light_projector_power_switch", status: "sensor.star_light_projector_status" }], entities: [] },
  {
    id: "lucas",
    title: "Lucas's Room",
    icon: "bed",
    group: "room",
    status: "live",
    kind: "control",
    lights: { groups: ["light.lucas_light"], bulbs: [] },
    media: ["media_player.lucas_bedroom_speaker"],
    entities: [],
  },
  {
    id: "cottage",
    title: "Cottage",
    icon: "home",
    group: "room",
    status: "live",
    kind: "control",
    // Moved from Tyler's Room. (light.tyler_s_air_purifier is labeled
    // "Tyler's Purifier Light" in HA.)
    lights: { groups: ["light.tyler_s_air_purifier"], bulbs: [] },
    entities: [],
  },
  {
    id: "exterior",
    title: "Exterior",
    icon: "sun",
    group: "room",
    status: "live",
    kind: "control",
    // Lights grouped by physical location.
    lightSections: [
      {
        name: "Front Porch",
        groups: ["light.front_porch_light_1", "light.front_porch_light_2"],
      },
      {
        name: "Porch",
        groups: [
          "light.porch_light_1",
          "light.porch_light_2",
          "light.porch_light_4",
          "light.porch_light_5",
          "light.porch_light_7",
          "light.porch_light_8",
        ],
      },
      {
        name: "Deck",
        groups: ["light.deck_lights", "light.deck_stairs"],
      },
      {
        name: "Patio",
        groups: ["light.grill_lights"],
      },
      {
        name: "Backyard",
        // flood lights per request; spotlights placed here too (adjust if wrong)
        groups: ["light.flood_lights", "light.spotlights_left", "light.spotlights_right"],
      },
    ],
    entities: [],
  },
];

// Collect every entity_id a panel references, across both the flat
// `entities` list and the structured control groups (lights/media/purifier).
function entitiesForPanel(p) {
  const ids = [...(p.entities ?? [])];
  if (p.lights) ids.push(...(p.lights.groups ?? []), ...(p.lights.bulbs ?? []));
  if (p.lightSections) {
    for (const s of p.lightSections) ids.push(...(s.groups ?? []));
  }
  if (p.media) ids.push(...p.media);
  if (p.deskSection?.media) ids.push(p.deskSection.media);
  if (p.purifier) ids.push(p.purifier.power, p.purifier.mode);
  if (p.switches) {
    for (const s of p.switches) ids.push(s.power, s.status);
  }
  // Climate panel
  if (p.thermostat) ids.push(p.thermostat);
  if (p.sensors) ids.push(...p.sensors);
  if (p.thermostatSensors) ids.push(p.thermostatSensors.humidity, p.thermostatSensors.temperature);
  if (p.airMonitors) {
    for (const m of p.airMonitors) ids.push(m.temp, m.humidity, m.aqi);
  }
  return ids.filter(Boolean);
}

// All entity_ids the dashboard needs from HA, derived from the panels above.
// Put this list into server/config.js -> homeAssistant.entities so the
// backend only fetches what's actually shown.
export const ALL_ENTITIES = [
  ...new Set(PANELS.flatMap(entitiesForPanel)),
];

export { entitiesForPanel };
