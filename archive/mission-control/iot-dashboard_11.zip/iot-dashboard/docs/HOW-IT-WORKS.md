# Understanding Your Home Dashboard — A Teaching Guide

This document teaches you how the dashboard works from the ground up. It assumes
**no prior knowledge** — if you've never seen this kind of project, start at the
top and read straight through. By the end you'll understand what every piece
does and be able to make your own changes confidently.

It's organized as a course:
1. The big picture (what this thing actually is)
2. The core concepts (the handful of ideas everything is built on)
3. A tour of every file (what each one does and when you'd touch it)
4. How a request actually flows through the system (following one button press)
5. Making your own changes (worked examples)
6. The mental models that make it all click

---

## 1. The big picture

You have a **web dashboard** for controlling your smart home. You open it in a
browser, see your rooms and devices, and tap things to control them.

Three separate pieces make that happen:

**The browser (the "frontend").** This is what you see and tap. It's a web page,
but a smart one — it updates itself, responds to taps, and talks to the server
behind the scenes. It's built with a tool called **React**.

**The server (the "backend").** This is a program running on your Windows Server
VM, always on. It's the middleman: the browser asks it for data ("what's the
state of the lights?") and tells it to do things ("turn on the lamp"). The
browser never talks to your devices directly — it only ever talks to this
server. The server is written in **JavaScript** and runs on **Node.js**.

**The data sources.** The server itself doesn't know anything about your devices.
It asks other systems:
- **Home Assistant (HA)** — the system that actually talks to your lights,
  thermostat, cameras, etc. The server asks HA for device states and tells HA to
  perform actions.
- **Microsoft Graph** — Microsoft's API, used for the Planner/Tasks panel.
- (There are also unused adapters for direct MQTT and HTTP devices, built in but
  not currently used.)

So the chain is: **You tap → browser → server → Home Assistant → your device.**
And back the other way for status. That's the entire system in one sentence.

```
   You (browser)  ⇄  Server (Node.js)  ⇄  Home Assistant  ⇄  Devices
                                       ⇄  Microsoft Graph  →  Planner
```

Why this split? Because the server can hold secrets (like the password to talk
to Home Assistant) that should never be in a browser, and it can present one
clean, unified view even though the data comes from several different places.

---

## 2. The core concepts

There are only a few ideas to understand. Everything else is detail.

### Concept A: The frontend and backend are separate programs

They live in two folders: `client/` (the frontend) and `server/` (the backend).
They're developed separately and even speak to each other over the network (via
web requests), even though they run on the same machine. This is why there are
two `package.json` files (one per program) and why you sometimes rebuild one
without the other.

### Concept B: The frontend must be "built" before it can run

You write the frontend in React (`.jsx` files) — a convenient, human-friendly
format. But browsers don't understand `.jsx` directly. So a tool called **Vite**
**compiles** (transforms) all the `.jsx` and `.css` into plain files a browser
understands, and puts them in a folder called `client/dist`. That's what
"building" means: `npm run build` turns your source code into `dist`.

**This is the single most important practical fact in this whole document:**
when you change the frontend, your changes don't appear until you *rebuild*.
Editing the file isn't enough — you must run `npm run build` to regenerate
`dist`, then restart the server so it serves the new `dist`.

The backend has no build step — Node runs its `.js` files directly. So backend
changes only need a restart, not a build.

### Concept C: The server serves the frontend AND answers data requests

The same server program does two jobs:
1. When you visit the dashboard, it hands your browser the built frontend files
   (the `dist` folder).
2. After that, the frontend repeatedly asks the server for data ("give me the
   device states") and the server answers.

That second job happens at addresses starting with `/api/` — like
`/api/devices`, `/api/planner`, `/api/camera/...`. These are the "doors" the
frontend knocks on. Each door is called an **endpoint**.

### Concept D: Polling — the dashboard asks again and again

The dashboard doesn't get instant push notifications when something changes.
Instead, it **polls**: every couple of seconds it asks the server "what's the
current state of everything?" and redraws. So when you change a light from
elsewhere, the dashboard notices within a couple seconds on its next poll. The
server, in turn, polls Home Assistant on its own schedule and keeps a cached
copy so it can answer the browser instantly.

### Concept E: The layout file is the heart of customization

One file — `client/src/layout.js` — defines every screen, every panel, and which
devices appear where. Most changes you'll ever want to make (add a room, move a
light, rename a screen) are edits to this one file. Understand this file and
you understand how to customize the dashboard.

### Concept F: Adapters — one per data source

The backend has a folder called `adapters/`. Each adapter is a self-contained
piece of code that knows how to talk to one external system: `homeAssistant.js`
talks to Home Assistant, `planner.js` talks to Microsoft Graph, and so on. They
all follow the same shape (a `poll()` function to read data, plus action
functions), which makes adding a new data source a matter of writing a new
adapter in the same mold.

---

## 3. A tour of every file

Here's what each file does and when you'd open it. The project has two halves —
`client/` (frontend) and `server/` (backend) — plus some top-level files.

### Top-level files

**`README.md`** — the original quick-start notes for setting up the project.

**`ENTITIES.txt`** — a generated, copy-paste-ready list of every Home Assistant
entity the dashboard needs. When you add devices in `layout.js`, you regenerate
this and paste it into the server's config so the backend knows to fetch them.

**`.gitignore`** — tells the Git version-control system which files NOT to save
(secrets, build output, downloaded libraries). You rarely touch it.

**`docs/`** — documentation, including this file, the developer reference, the
customization guide, and the family setup instructions.

### The backend — `server/`

**`server/server.js`** — the heart of the backend (~150 lines). This is the
program that runs. It:
- Creates each adapter (Home Assistant, Planner, etc.).
- Runs background loops that poll those sources and cache the results.
- Defines all the `/api/...` endpoints the frontend calls.
- Serves the built frontend (`client/dist`) to browsers.
You'd edit this to add a new endpoint or change how often things poll.

**`server/config.js`** — your private settings: the Home Assistant address and
access token, the Planner credentials, which devices to fetch. **This file holds
secrets and is never shared or put in version control.** It doesn't ship with the
project — you create it by copying `config.example.js`. This is the first file
you set up, and the one you edit when adding devices or changing credentials.

**`server/config.example.js`** — a template showing what `config.js` should look
like, with placeholder values. You copy it to `config.js` and fill in real
values. It's safe to share because it has no real secrets.

**`server/adapters/`** — one file per data source:
- **`homeAssistant.js`** — talks to Home Assistant. Reads device states
  (`poll`), sends commands (`callService`), and fetches camera images
  (`getCameraSnapshot`). This is the busiest adapter.
- **`planner.js`** — talks to Microsoft Graph for the Tasks panel. Handles
  Microsoft login (getting an access token), reading plans/tasks, completing
  tasks, and creating tasks.
- **`httpDevices.js`** and **`mqttDevices.js`** — adapters for talking to
  devices directly (not through Home Assistant). Built and ready, but not
  currently used in your setup.

**`server/package.json`** — lists the backend's library dependencies (like
Express, the web-server library). `npm install` reads this to download them.

### The frontend — `client/`

**`client/index.html`** — the bare HTML page the browser loads first. It's nearly
empty; it just provides a spot (`<div id="root">`) where React draws everything.

**`client/src/main.jsx`** — the tiny starting point (10 lines) that tells React
to take over that `root` spot and render the app.

**`client/src/App.jsx`** — the main frontend program (~400 lines). It:
- Handles navigation (which screen you're on — the landing page vs. a panel).
- Polls the server for data every couple seconds.
- Decides which kind of panel to draw (a room with controls, the climate screen,
  the cameras, the tasks panel, etc.).
- Draws the landing screen with its tiles and the "needs attention" alerts.
You'd edit this to change how panels are laid out or add a new *type* of panel.

**`client/src/layout.js`** — THE customization file (~287 lines). Defines every
panel and what's in it. Covered in depth in Section 5. **This is where you'll
make most changes.**

**`client/src/Controls.jsx`** — all the interactive widgets (~700 lines). The
light toggle, the brightness slider, the thermostat, the media/activity buttons,
the camera card, the Planner panel — each is a small self-contained component
here. You'd edit this to change how a control *looks or behaves*.

**`client/src/Icon.jsx`** — the simple line icons used on panel tiles (the couch,
bed, thermometer, etc.), drawn as code. You'd edit this to add a new tile icon.

**`client/src/BrandIcon.jsx`** — the brand logos for the streaming/console
buttons (Disney+, HBO Max, PlayStation, etc.). Separate from `Icon.jsx` because
brand logos are "filled" shapes while the UI icons are "outline" shapes.

**`client/src/styles.css`** — all the visual styling: colors, spacing, sizes,
fonts. The color palette lives at the very top as "variables" you can change to
re-theme the whole dashboard at once.

**`client/vite.config.js`** — configuration for the build tool. You rarely touch
it.

**`client/package.json`** — lists the frontend's libraries (React, Vite). Like
the backend's, `npm install` reads it.

---

## 4. Following one button press all the way through

The best way to *understand* the system is to trace one action end to end. Let's
follow what happens when you tap a light toggle to turn it on.

1. **You tap the toggle.** It's drawn by the `LightControl` component in
   `Controls.jsx`. The tap triggers its `toggle()` function.

2. **The frontend updates instantly (optimistically).** The toggle flips to "on"
   immediately so it feels responsive — before the light has even responded. (If
   the command fails, it flips back.)

3. **The frontend calls the server.** `toggle()` sends a web request to the
   server's `/api/service` endpoint, with a little package of data saying "turn
   on this light entity."

4. **The server checks it's allowed.** In `server.js`, the `/api/service`
   endpoint checks the request against an **allowlist** — a fixed list of
   permitted actions. Turning a light on/off is on the list; something dangerous
   wouldn't be. This is a safety boundary.

5. **The server tells Home Assistant.** It calls the `callService` function in
   `homeAssistant.js`, which sends the actual command to Home Assistant's API
   using your access token.

6. **Home Assistant turns on the light.** HA talks to the physical device.

7. **The server refreshes its data.** After a successful command, the server
   immediately re-polls HA so its cached state is current.

8. **The next poll confirms it.** Within ~2 seconds the frontend's regular poll
   of `/api/devices` returns the new state, and the toggle's optimistic guess is
   confirmed (or corrected) against reality.

Every action in the dashboard follows this same shape: **component → /api
endpoint → allowlist check → adapter → external system → refresh → poll
confirms.** Once you see it for one button, you see it for all of them.

---

## 5. Making your own changes

Here are the changes you're most likely to want, from easiest to most involved.
After ANY frontend change, remember Concept B: rebuild and restart (Section 6
has the exact commands).

### Change the colors / theme

Open `client/src/styles.css`. At the very top is a block called `:root` full of
color "variables" like `--accent` (the amber highlight). Change a value, rebuild,
and it updates everywhere that uses it. This is the safest, highest-impact
change.

### Add a light to a room

1. Find the device's **entity ID** in Home Assistant (Developer Tools → States,
   e.g. `light.guest_lamp`).
2. Open `client/src/layout.js`, find the room's panel, and add the entity ID to
   its `lights.groups` list.
3. Add the same entity ID to `server/config.js`'s entities list (so the backend
   fetches it). Regenerate `ENTITIES.txt` if you want the full list (Section 6).
4. Rebuild and restart.

### Add a whole new room

In `layout.js`, copy an existing room's block, change the `id`, `title`, `icon`,
and the light entity IDs. Set `status: "live"`. That's it — the landing screen
picks it up automatically because it just lists whatever rooms are in the file.

### Rename or reorder screens

In `layout.js`: change a panel's `title` to rename it. Move a panel's block up or
down in the list to reorder it on the landing screen. Change its `group` between
`"room"` and `"global"` to move it between sections.

### Change how a control looks or behaves

Open `Controls.jsx` and find the relevant component (e.g. `LightControl`,
`ThermostatControl`). This is more advanced — it's actual program logic — but the
components are small and self-contained, so you can usually find and adjust the
piece you want. The customization guide (`CUSTOMIZATION-GUIDE.md`) has worked
examples like "make a card turn red when a value is too high."

### Add a new icon

For a panel tile icon, add it to `Icon.jsx`. For a brand logo, add it to
`BrandIcon.jsx`. Both take SVG "path" data, which you can get from a free icon
site like simpleicons.org.

### Add devices to the config

Whatever you add in `layout.js`, the backend only *fetches* entities listed in
`server/config.js`. Keep them in sync. The helper command in Section 6
regenerates the full list for you so you don't assemble it by hand.

---

## 6. The mental models that make it click

A few framings that tie everything together:

**"The layout file is a description; the components are the drawing tools."**
`layout.js` says *what* should appear (this room has these lights). The
components in `Controls.jsx` know *how* to draw and operate each kind of thing.
App.jsx is the director that reads the layout and assigns each panel to the right
component.

**"The backend is a careful translator."** It speaks "browser" on one side and
"Home Assistant / Microsoft Graph" on the other, holds the secrets needed to do
so, and refuses to pass along any request that isn't on its allowlist.

**"Build = publish."** Editing a frontend file is like editing a draft. Running
`npm run build` is like publishing it. The server always serves the
last-published version, never your unpublished draft. If a change isn't showing
up, you almost certainly forgot to publish (build) or to restart, or your browser
cached the old version (fix: hard-refresh with Ctrl+Shift+R).

**"Config is yours; code is shared."** The code files are the same for anyone
running this dashboard. `config.js` is what makes it *yours* — your token, your
devices, your credentials. That's why it's kept separate and secret.

### The deploy routine (memorize this)

After any change, on the server:

```powershell
cd C:\apps\iot-dashboard\client
npm install        # only strictly needed if libraries changed; harmless otherwise
npm run build      # REQUIRED for any frontend change — "publishes" your edits
cd ..\server
npm install        # only if the backend changed
$nssm = "C:\tools\nssm.exe"
& $nssm restart IoTDashboard
```

Then **hard-refresh the browser** (Ctrl+Shift+R) so it loads the freshly built
files instead of a cached copy.

### Regenerating the entities list

When you add devices in `layout.js`, regenerate the list for `config.js`:

```powershell
cd C:\apps\iot-dashboard\client\src
node --input-type=module -e "import {ALL_ENTITIES} from './layout.js'; console.log(JSON.stringify(ALL_ENTITIES, null, 2))"
```

Paste the result into `server/config.js` under the Home Assistant `entities`
list.

### When something breaks

- **Change didn't appear?** You didn't rebuild, didn't restart, or need a
  hard-refresh.
- **Dashboard won't load at all?** Check the service is running
  (`Get-Service IoTDashboard`) and listening (`Get-NetTCPConnection -LocalPort
  8080 -State Listen`). If it works at `localhost:8080` on the server but not
  elsewhere, it's a network issue, not a dashboard issue.
- **A control does nothing?** The entity ID in `layout.js` probably doesn't match
  Home Assistant exactly, or the action isn't on the server's allowlist.
- **See the real error:** stop the service and run `node server.js` by hand in
  the `server` folder to watch its output live.

---

## Where to go next

- **`CUSTOMIZATION-GUIDE.md`** — focused, worked examples of styling and
  status-based changes (buttons that change color, etc.).
- **`DEVELOPER-GUIDE.md`** — the reference manual: architecture, security model,
  operations runbook, and a troubleshooting table.
- **This file** — the conceptual foundation that makes those two make sense.

The most important habit: when you want to change *what appears*, reach for
`layout.js`. When you want to change *how something looks*, reach for
`styles.css`. When you want to change *how something works*, reach for
`Controls.jsx`. And always rebuild + restart + hard-refresh to see it.
