// config.example.js
// Copy this to config.js and fill in your real values.
// config.js is gitignored so your tokens never get committed.

export default {
  // Port the dashboard listens on. Because access is via Tailscale,
  // binding to 0.0.0.0 is fine — only tailnet devices can route here.
  port: 8080,

  // How often (ms) to poll HTTP/HA sources. "Every few seconds is fine."
  pollIntervalMs: 5000,

  // ---- Home Assistant ----
  homeAssistant: {
    enabled: true,
    // Base URL of your HA instance, no trailing slash.
    baseUrl: "http://homeassistant.local:8123",
    // Long-Lived Access Token from HA profile page (Bearer token, 10yr).
    token: "PASTE_YOUR_LONG_LIVED_TOKEN_HERE",
    // Only surface these entities. Empty array = all states.
    entities: [
      // "sensor.living_room_temperature",
      // "light.kitchen",
    ],
  },

  // ---- Govee lights (direct control, bypasses Home Assistant) ----
  // LAN is preferred per-device (set lanIp); cloud is the fallback (needs
  // apiKey from the Govee Home app: account icon -> Apply for API Key).
  // mac + sku come from the cloud /devices list or the Govee app.
  govee: {
    enabled: false,
    apiKey: "YOUR_GOVEE_API_KEY", // for cloud path + state reads
    devices: [
      // {
      //   id: "rec_floor_lamp",        // your short id, used in the dashboard
      //   name: "Rec Room Floor Lamp",
      //   sku: "H6076",                // model, from the Govee app/cloud list
      //   mac: "AA:BB:CC:DD:EE:FF:11:22", // device id from cloud list
      //   lanIp: "192.168.230.50",     // optional: set to enable local LAN control
      // },
    ],
  },

  // ---- Microsoft Planner (via Microsoft Graph, app-only auth) ----
  // Requires an Entra ID App Registration with application permissions
  // Tasks.ReadWrite.All and Group.Read.All (admin-consented) + a client secret.
  planner: {
    enabled: false,
    tenantId: "YOUR_DIRECTORY_TENANT_ID",
    clientId: "YOUR_APPLICATION_CLIENT_ID",
    clientSecret: "YOUR_CLIENT_SECRET_VALUE",
    pollIntervalMs: 60000, // Planner changes slowly; 60s respects rate limits
    // App-only auth can't enumerate "my" plans, so list the plan IDs to show.
    // Get a plan's ID from its URL in Planner, or via Graph Explorer.
    planIds: [
      // "PLAN_ID_1",
      // "PLAN_ID_2",
    ],
  },

  // ---- Direct devices polled over HTTP/REST ----
  // response into { value, unit } however that device reports.
  httpDevices: [
    // {
    //   id: "garage_temp",
    //   name: "Garage Temperature",
    //   url: "http://192.168.230.40/api/sensor",
    //   parse: (json) => ({ value: json.temp_c, unit: "°C" }),
    // },
  ],

  // ---- Direct devices that publish over MQTT ----
  mqtt: {
    enabled: false,
    brokerUrl: "mqtt://192.168.230.30:1883",
    username: "",
    password: "",
    // Topics to subscribe to; each maps to a device id shown on the dash.
    subscriptions: [
      // { id: "shed_humidity", name: "Shed Humidity", topic: "shed/humidity", unit: "%" },
    ],
  },
};
