// adapters/planner.js
// Microsoft Graph Planner integration using app-only (client credentials) auth.
// Fetches plans and tasks; supports completing and creating tasks.
//
// Requires an Entra ID App Registration with application permissions
// Tasks.ReadWrite.All and Group.Read.All (admin-consented), and a client secret.

const GRAPH = "https://graph.microsoft.com/v1.0";

export function createPlannerAdapter(cfg) {
  if (!cfg?.enabled) {
    return {
      poll: async () => ({ ok: false, plans: [], error: "disabled" }),
      completeTask: async () => ({ ok: false, error: "Planner disabled" }),
      createTask: async () => ({ ok: false, error: "Planner disabled" }),
    };
  }

  const tokenUrl = `https://login.microsoftonline.com/${cfg.tenantId}/oauth2/v2.0/token`;
  let cachedToken = null;
  let tokenExpiry = 0;

  // --- token management: fetch & cache an app-only token ---
  async function getToken() {
    const now = Date.now();
    if (cachedToken && now < tokenExpiry - 60000) return cachedToken; // 60s buffer
    const body = new URLSearchParams({
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      scope: "https://graph.microsoft.com/.default",
      grant_type: "client_credentials",
    });
    const res = await fetch(tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`Token request failed: HTTP ${res.status} ${txt.slice(0, 200)}`);
    }
    const data = await res.json();
    cachedToken = data.access_token;
    tokenExpiry = now + data.expires_in * 1000;
    return cachedToken;
  }

  async function graph(path, options = {}) {
    const token = await getToken();
    const res = await fetch(`${GRAPH}${path}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
    });
    return res;
  }

  // --- read: list the configured plans and their tasks ---
  // cfg.planIds is an array of plan IDs to show (app-only can't enumerate
  // "my" plans without a user context, so we read explicitly-listed plans).
  async function poll() {
    try {
      const planIds = cfg.planIds ?? [];
      const plans = [];
      for (const planId of planIds) {
        // plan details (for the title)
        const planRes = await graph(`/planner/plans/${planId}`);
        if (!planRes.ok) {
          plans.push({ id: planId, title: planId, ok: false, error: `HTTP ${planRes.status}`, tasks: [] });
          continue;
        }
        const plan = await planRes.json();
        // tasks in the plan
        const tasksRes = await graph(`/planner/plans/${planId}/tasks`);
        const tasksJson = tasksRes.ok ? await tasksRes.json() : { value: [] };
        const tasks = (tasksJson.value ?? []).map((t) => ({
          id: t.id,
          title: t.title,
          percentComplete: t.percentComplete, // 0 / 50 / 100
          completed: t.percentComplete === 100,
          dueDateTime: t.dueDateTime ?? null,
          bucketId: t.bucketId ?? null,
          etag: t["@odata.etag"], // needed for PATCH/complete
        }));
        plans.push({ id: planId, title: plan.title, ok: true, tasks });
      }
      return { ok: true, plans };
    } catch (err) {
      return { ok: false, plans: [], error: err.message };
    }
  }

  // --- write: mark a task complete (PATCH percentComplete=100) ---
  // Graph requires the current etag in an If-Match header for task updates.
  async function completeTask({ taskId, etag, complete = true }) {
    try {
      const res = await graph(`/planner/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "If-Match": etag },
        body: JSON.stringify({ percentComplete: complete ? 100 : 0 }),
      });
      if (!res.ok) {
        const txt = await res.text();
        return { ok: false, error: `HTTP ${res.status} ${txt.slice(0, 200)}` };
      }
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }

  // --- write: create a new task in a plan ---
  async function createTask({ planId, title, bucketId = null }) {
    try {
      const payload = { planId, title };
      if (bucketId) payload.bucketId = bucketId;
      const res = await graph(`/planner/tasks`, {
        method: "POST",
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const txt = await res.text();
        return { ok: false, error: `HTTP ${res.status} ${txt.slice(0, 200)}` };
      }
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }

  return { poll, completeTask, createTask };
}
