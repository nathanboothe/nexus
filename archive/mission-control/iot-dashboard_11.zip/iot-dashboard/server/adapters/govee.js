// adapters/govee.js
// Controls Govee lights directly (no Home Assistant). Two transports:
//   • LAN  — UDP protocol, fully local, no cloud. Per-device, must be enabled
//            in the Govee Home app, and only supported on some models.
//   • Cloud — Govee Developer HTTP API, needs an API key, goes through Govee.
//
// Strategy: for each configured device, prefer LAN if it has a `lanIp`,
// otherwise use the cloud API. Built so a device can use either.
//
// LAN protocol reference (documented by Govee):
//   control  -> send UDP JSON to device IP, port 4003
//   commands -> turn (0/1), brightness (0-100), colorwc (rgb / colorTemInKelvin)
//
// NOTE: the LAN path uses UDP and could not be exercised against real hardware
// in development. The message formats follow Govee's published spec, but LAN
// behavior should be confirmed against your actual devices. The cloud path is
// plain HTTP and was tested.

import dgram from "node:dgram";

const GOVEE_CLOUD = "https://developer-api.govee.com/v1";
const LAN_CONTROL_PORT = 4003;

export function createGoveeAdapter(cfg) {
  if (!cfg?.enabled) {
    return {
      poll: async () => [],
      control: async () => ({ ok: false, error: "Govee disabled" }),
    };
  }

  const devices = cfg.devices ?? []; // [{ id, name, sku, mac, lanIp? }]
  const apiKey = cfg.apiKey || null;

  // ---------- LAN transport (UDP) ----------
  function lanSend(ip, message) {
    return new Promise((resolve) => {
      const socket = dgram.createSocket("udp4");
      const payload = Buffer.from(JSON.stringify(message));
      socket.send(payload, LAN_CONTROL_PORT, ip, (err) => {
        socket.close();
        resolve(err ? { ok: false, error: err.message } : { ok: true });
      });
    });
  }

  async function lanControl(device, action) {
    // Translate a normalized action into Govee LAN command JSON.
    let msg;
    if (action.type === "turn") {
      msg = { msg: { cmd: "turn", data: { value: action.on ? 1 : 0 } } };
    } else if (action.type === "brightness") {
      msg = { msg: { cmd: "brightness", data: { value: action.pct } } }; // 0-100
    } else if (action.type === "color") {
      msg = {
        msg: {
          cmd: "colorwc",
          data: { color: { r: action.r, g: action.g, b: action.b }, colorTemInKelvin: 0 },
        },
      };
    } else {
      return { ok: false, error: `Unsupported LAN action: ${action.type}` };
    }
    return lanSend(device.lanIp, msg);
  }

  // ---------- Cloud transport (HTTP) ----------
  async function cloudControl(device, action) {
    if (!apiKey) return { ok: false, error: "No Govee API key configured" };
    // Map normalized action to the cloud API's cmd shape.
    let cmd;
    if (action.type === "turn") {
      cmd = { name: "turn", value: action.on ? "on" : "off" };
    } else if (action.type === "brightness") {
      cmd = { name: "brightness", value: action.pct }; // 0-100
    } else if (action.type === "color") {
      cmd = { name: "color", value: { r: action.r, g: action.g, b: action.b } };
    } else {
      return { ok: false, error: `Unsupported cloud action: ${action.type}` };
    }
    try {
      const res = await fetch(`${GOVEE_CLOUD}/devices/control`, {
        method: "PUT",
        headers: { "Govee-API-Key": apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ device: device.mac, model: device.sku, cmd }),
      });
      if (!res.ok) {
        const txt = await res.text();
        return { ok: false, error: `HTTP ${res.status} ${txt.slice(0, 150)}` };
      }
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }

  // ---------- cloud state read (for poll) ----------
  async function cloudState(device) {
    if (!apiKey) return null;
    try {
      const url = `${GOVEE_CLOUD}/devices/state?device=${encodeURIComponent(
        device.mac
      )}&model=${encodeURIComponent(device.sku)}`;
      const res = await fetch(url, { headers: { "Govee-API-Key": apiKey } });
      if (!res.ok) return null;
      const data = await res.json();
      const props = data?.data?.properties ?? [];
      const get = (k) => {
        const p = props.find((x) => k in x);
        return p ? p[k] : null;
      };
      const power = get("powerState"); // "on" / "off"
      const brightness = get("brightness");
      return {
        value: power ?? "unknown",
        attrs: { brightness: brightness != null ? Math.round((brightness / 100) * 255) : null },
      };
    } catch {
      return null;
    }
  }

  // ---------- public API ----------
  // Normalized device shape matching the rest of the dashboard.
  async function poll() {
    const out = [];
    for (const d of devices) {
      // State can only be read via cloud (LAN doesn't reliably report state).
      const state = await cloudState(d);
      out.push({
        id: `govee.${d.id}`,
        name: d.name,
        source: "govee",
        ok: true,
        value: state?.value ?? "unknown",
        unit: "",
        transport: d.lanIp ? "lan" : "cloud",
        attrs: state?.attrs ?? { brightness: null },
      });
    }
    return out;
  }

  // action: { type:"turn", on } | { type:"brightness", pct } | { type:"color", r,g,b }
  async function control(deviceId, action) {
    const d = devices.find((x) => x.id === deviceId || `govee.${x.id}` === deviceId);
    if (!d) return { ok: false, error: `Unknown Govee device: ${deviceId}` };
    // Prefer LAN when an IP is set; fall back to cloud on failure.
    if (d.lanIp) {
      const lan = await lanControl(d, action);
      if (lan.ok) return { ok: true, via: "lan" };
      // LAN failed — try cloud if we can
      const cloud = await cloudControl(d, action);
      return cloud.ok ? { ok: true, via: "cloud-fallback" } : cloud;
    }
    const cloud = await cloudControl(d, action);
    return cloud.ok ? { ok: true, via: "cloud" } : cloud;
  }

  return { poll, control };
}
